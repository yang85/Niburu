Versions:
JUnit.jar 4.12
Hamcrestcore.jar 1.3

IDE: Eclipse

Required Libraries:
JRE System Library [JavaSE-1.8]
JUnit 5

Instructions:
	1. Make sure environment variables are set properly for your installation of JUnit.
	2. In Eclipse, go to the properties of the project file and add the JUnit5 library
	   to the list of libraries.
	3. Run TestN.java as a JUnit test.
	4. Results of the test cases will be displayed in the System window.